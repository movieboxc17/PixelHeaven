// DOM Elements
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;
const loadingScreen = document.querySelector('.loading-screen');
const searchToggle = document.querySelector('.search-toggle');
const searchOverlay = document.querySelector('.search-overlay');
const closeSearch = document.querySelector('.close-search');
const quantityInputs = document.querySelectorAll('.cart-quantity');
const qtyButtons = document.querySelectorAll('.qty-btn');
const productThumbnails = document.querySelectorAll('.product-thumbnail');
const mainProductImage = document.querySelector('.product-main-image img');
const colorOptions = document.querySelectorAll('.color-option');
const sizeOptions = document.querySelectorAll('.size-option');
const tabButtons = document.querySelectorAll('.tab-btn');
const tabPanes = document.querySelectorAll('.tab-pane');
const wishlistBtn = document.querySelector('.wishlist-btn');
const checkoutSteps = document.querySelectorAll('.checkout-step');
const progressSteps = document.querySelectorAll('.progress-step');
const nextButtons = document.querySelectorAll('[id^="to-"]');
const backButtons = document.querySelectorAll('[id^="back-to-"]');
const showCouponBtn = document.getElementById('show-coupon');
const couponForm = document.querySelector('.coupon-form');
const checkoutForm = document.getElementById('checkout-form');
const shippingOptions = document.querySelectorAll('input[name="shipping"]');
const sameShippingCheckbox = document.getElementById('same-shipping');
const shippingAddressSection = document.querySelector('.shipping-address');
const orderConfirmation = document.querySelector('.order-confirmation');

// Initialize theme from localStorage
document.addEventListener('DOMContentLoaded', function() {
    // Show loading screen
    setTimeout(() => {
        loadingScreen.classList.add('fade-out');
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }, 1000);
    
    // Initialize theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.className = savedTheme;
        updateThemeIcon();
    }
    
    // Initialize product skeletons with real products
    initializeProducts();
});

// Theme toggle functionality
themeToggle.addEventListener('click', function() {
    if (body.classList.contains('light-mode') || !body.classList.contains('dark-mode')) {
        body.className = 'dark-mode';
    } else {
        body.className = 'light-mode';
    }
    
    localStorage.setItem('theme', body.className);
    updateThemeIcon();
});

function updateThemeIcon() {
    const icon = themeToggle.querySelector('i');
    if (body.classList.contains('dark-mode')) {
        icon.className = 'fas fa-sun';
    } else {
        icon.className = 'fas fa-moon';
    }
}

// Search functionality
searchToggle.addEventListener('click', function() {
    searchOverlay.classList.add('active');
    searchOverlay.querySelector('input').focus();
    document.body.style.overflow = 'hidden';
});

closeSearch.addEventListener('click', function() {
    searchOverlay.classList.remove('active');
    document.body.style.overflow = '';
});

// Product thumbnail functionality
if (productThumbnails.length > 0 && mainProductImage) {
    productThumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            const imgSrc = this.querySelector('img').src;
            mainProductImage.src = imgSrc;
            
            // Update active state
            productThumbnails.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Color selection functionality
if (colorOptions.length > 0) {
    colorOptions.forEach(option => {
        option.addEventListener('click', function() {
            colorOptions.forEach(o => o.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Size selection functionality
if (sizeOptions.length > 0) {
    sizeOptions.forEach(option => {
        option.addEventListener('click', function() {
            if (!this.classList.contains('out-of-stock')) {
                sizeOptions.forEach(o => o.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
}

// Product tabs functionality
if (tabButtons.length > 0) {
    tabButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));
            
            this.classList.add('active');
            tabPanes[index].classList.add('active');
        });
    });
}

// Wishlist toggle
if (wishlistBtn) {
    wishlistBtn.addEventListener('click', function() {
        const icon = this.querySelector('i');
        if (icon.classList.contains('far')) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            showToast('Product added to wishlist!');
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            showToast('Product removed from wishlist!');
        }
    });
}

// Quantity buttons
if (qtyButtons.length > 0) {
    qtyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const currentValue = parseInt(input.value);
            
            if (this.classList.contains('minus') && currentValue > 1) {
                input.value = currentValue - 1;
            } else if (this.classList.contains('plus')) {
                input.value = currentValue + 1;
            }
            
            // Trigger change event to update cart if on cart page
            if (input.classList.contains('cart-quantity')) {
                input.dispatchEvent(new Event('change'));
            }
        });
    });
}

// Cart quantity change
if (quantityInputs.length > 0) {
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            const cartItem = this.closest('.cart-item');
            const quantity = parseInt(this.value);
            const price = parseFloat(cartItem.querySelector('.cart-price').textContent.replace('$', ''));
            const total = (price * quantity).toFixed(2);
            
            cartItem.querySelector('.cart-total').textContent = '$' + total;
            updateCartTotals();
        });
    });
}

// Update cart totals
function updateCartTotals() {
    const cartTotals = document.querySelectorAll('.cart-total');
    let subtotal = 0;
    
    cartTotals.forEach(total => {
        subtotal += parseFloat(total.textContent.replace('$', ''));
    });
    
    const subtotalElement = document.querySelector('.subtotal-price');
    const shippingElement = document.querySelector('.shipping-price');
    const totalElement = document.querySelector('.total-price');
    
    if (subtotalElement && shippingElement && totalElement) {
        const shipping = parseFloat(shippingElement.textContent.replace('$', ''));
        const total = (subtotal + shipping).toFixed(2);
        
        subtotalElement.textContent = '$' + subtotal.toFixed(2);
        totalElement.textContent = '$' + total;
    }
}

// Checkout steps functionality
if (nextButtons.length > 0) {
    nextButtons.forEach(button => {
        button.addEventListener('click', function() {
            const currentStep = this.closest('.checkout-step');
            const currentIndex = Array.from(checkoutSteps).indexOf(currentStep);
            
            // Perform validation here before proceeding
            
            // If valid, proceed to next step
            currentStep.classList.remove('active');
            checkoutSteps[currentIndex + 1].classList.add('active');
            
            // Update progress steps
            progressSteps[currentIndex].classList.add('completed');
            progressSteps[currentIndex + 1].classList.add('active');
        });
    });
}

if (backButtons.length > 0) {
    backButtons.forEach(button => {
        button.addEventListener('click', function() {
            const currentStep = this.closest('.checkout-step');
            const currentIndex = Array.from(checkoutSteps).indexOf(currentStep);
            
            currentStep.classList.remove('active');
            checkoutSteps[currentIndex - 1].classList.add('active');
            
            // Update progress steps
            progressSteps[currentIndex].classList.remove('active');
            progressSteps[currentIndex - 1].classList.remove('completed');
            progressSteps[currentIndex - 1].classList.add('active');
        });
    });
}

// Coupon form toggle
if (showCouponBtn && couponForm) {
    showCouponBtn.addEventListener('click', function() {
        couponForm.style.display = couponForm.style.display === 'none' ? 'flex' : 'none';
        const icon = this.querySelector('i');
        icon.className = couponForm.style.display === 'none' ? 'fas fa-plus' : 'fas fa-minus';
    });
}

// Shipping option change
if (shippingOptions.length > 0) {
    shippingOptions.forEach(option => {
        option.addEventListener('change', function() {
            const shippingCost = this.closest('.shipping-option').querySelector('.shipping-price').textContent;
            const shippingCostElement = document.getElementById('shipping-cost');
            
            if (shippingCostElement) {
                shippingCostElement.textContent = shippingCost;
                
                // Update total
                const subtotal = parseFloat(document.querySelector('.subtotal-price').textContent.replace('$', ''));
                const shipping = parseFloat(shippingCost.replace('$', ''));
                const tax = parseFloat(document.querySelector('.summary-row:nth-child(3) span:last-child').textContent.replace('$', ''));
                const total = (subtotal + shipping + tax).toFixed(2);
                
                document.getElementById('total-cost').textContent = '$' + total;
            }
        });
    });
}

// Same shipping address toggle
if (sameShippingCheckbox && shippingAddressSection) {
    sameShippingCheckbox.addEventListener('change', function() {
        shippingAddressSection.style.display = this.checked ? 'none' : 'block';
    });
}

// Checkout form submission
if (checkoutForm && orderConfirmation) {
    checkoutForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show order confirmation
        orderConfirmation.style.display = 'flex';
        
        // Set customer email in confirmation
        const emailInput = document.getElementById('email');
        const customerEmail = document.getElementById('customer-email');
        
        if (emailInput && customerEmail) {
            customerEmail.textContent = emailInput.value;
        }
    });
}

// Initialize products
function initializeProducts() {
    const productSkeletons = document.querySelectorAll('.product-skeleton');
    
    if (productSkeletons.length > 0) {
        // Fake API call to simulate loading products
        setTimeout(() => {
            productSkeletons.forEach(skeleton => {
                // Replace skeleton with product card
                skeleton.outerHTML = createProductCard();
            });
            
            // Add event listeners to newly created product cards
            addProductCardListeners();
        }, 1500);
    }
}

function createProductCard() {
    const products = [
        {
            id: 1,
            title: 'Cotton T-Shirt',
            price: 35.99,
            oldPrice: 45.99,
            discount: '22%',
            image: 'https://via.placeholder.com/300?text=TShirt',
            rating: 4.5,
            reviews: 128,
            category: 'clothing'
        },
        {
            id: 2,
            title: 'Slim Fit Jeans',
            price: 59.99,
            oldPrice: 79.99,
            discount: '25%',
            image: 'https://via.placeholder.com/300?text=Jeans',
            rating: 4.2,
            reviews: 97,
            category: 'clothing'
        },
        {
            id: 3,
            title: 'Classic Sneakers',
            price: 79.99,
            oldPrice: 99.99,
            discount: '20%',
            image: 'https://via.placeholder.com/300?text=Sneakers',
            rating: 4.7,
            reviews: 213,
            category: 'footwear'
        },
        {
            id: 4,
            title: 'Leather Wallet',
            price: 29.99,
            oldPrice: 39.99,
            discount: '25%',
            image: 'https://via.placeholder.com/300?text=Wallet',
            rating: 4.4,
            reviews: 76,
            category: 'accessories'
        },
        {
            id: 5,
            title: 'Wireless Headphones',
            price: 119.99,
            oldPrice: 149.99,
            discount: '20%',
            image: 'https://via.placeholder.com/300?text=Headphones',
            rating: 4.6,
            reviews: 315,
            category: 'electronics'
        },
        {
            id: 6,
            title: 'Backpack',
            price: 49.99,
            oldPrice: 69.99,
            discount: '29%',
            image: 'https://via.placeholder.com/300?text=Backpack',
            rating: 4.3,
            reviews: 189,
            category: 'accessories'
        }
    ];
    
    // Get random product
    const product = products[Math.floor(Math.random() * products.length)];
    
    return `
        <div class="product-card" data-id="${product.id}" data-category="${product.category}">
            <div class="product-image">
                <img src="${product.image}" alt="${product.title}">
                <div class="product-badge">${product.discount} OFF</div>
                <div class="product-actions">
                    <button class="wishlist-toggle"><i class="far fa-heart"></i></button>
                    <button class="quickview-toggle"><i class="far fa-eye"></i></button>
                </div>
            </div>
            <div class="product-info">
                <div class="product-category">${product.category}</div>
                <h3 class="product-title">${product.title}</h3>
                <div class="product-price">
                    <span class="current-price">$${product.price}</span>
                    <span class="old-price">$${product.oldPrice}</span>
                </div>
                <div class="product-rating">
                    ${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}
                    <span>${product.reviews} reviews</span>
                </div>
                <button class="btn primary-btn add-to-cart-btn"><i class="fas fa-shopping-cart"></i> Add to Cart</button>
            </div>
        </div>
    `;
}

function addProductCardListeners() {
    // Add to cart buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    if (addToCartButtons.length > 0) {
        addToCartButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productCard = this.closest('.product-card');
                const productId = productCard.dataset.id;
                const productTitle = productCard.querySelector('.product-title').textContent;
                
                // Update cart count
                const cartCount = document.querySelector('.cart-count');
                if (cartCount) {
                    const currentCount = parseInt(cartCount.textContent);
                    cartCount.textContent = currentCount + 1;
                }
                
                // Show toast notification
                showToast(`${productTitle} added to cart!`);
            });
        });
    }
    
    // Wishlist toggle buttons
    const wishlistToggleButtons = document.querySelectorAll('.wishlist-toggle');
    if (wishlistToggleButtons.length > 0) {
        wishlistToggleButtons.forEach(button => {
            button.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (icon.classList.contains('far')) {
                    icon.classList.remove('far');
                    icon.classList.add('fas');
                    showToast('Product added to wishlist!');
                } else {
                    icon.classList.remove('fas');
                    icon.classList.add('far');
                    showToast('Product removed from wishlist!');
                }
            });
        });
    }
    
    // Quick view buttons
    const quickviewButtons = document.querySelectorAll('.quickview-toggle');
    if (quickviewButtons.length > 0) {
        quickviewButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productCard = this.closest('.product-card');
                const productId = productCard.dataset.id;
                
                // In a real application, you would fetch product details here
                // and open a quick view modal
                alert(`Quick view for product ID: ${productId}`);
            });
        });
    }
}

// Create and show a toast notification
function showToast(message, type = 'success', duration = 3000) {
    // Remove existing toasts
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    // Add to body
    document.body.appendChild(toast);
    
    // Show toast with animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Hide and remove after duration
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, duration);
}

// Initialize for cart page
function initializeCartPage() {
    const removeButtons = document.querySelectorAll('.remove-item');
    if (removeButtons.length > 0) {
        removeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const cartItem = this.closest('.cart-row');
                
                // Add fade-out animation
                cartItem.style.opacity = '0';
                cartItem.style.transform = 'translateX(20px)';
                
                // Remove after animation
                setTimeout(() => {
                    cartItem.remove();
                    updateCartTotals();
                    
                    // If no items left, show empty cart message
                    const cartItems = document.querySelectorAll('.cart-row');
                    if (cartItems.length <= 1) { // Only header row left
                        const cartContainer = document.querySelector('.cart-container');
                        cartContainer.innerHTML = `
                            <div class="cart-empty">
                                <div class="empty-cart-icon">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                                <h2>Your cart is empty</h2>
                                <p>Looks like you haven't added anything to your cart yet.</p>
                                <a href="index.html" class="btn primary-btn">Continue Shopping</a>
                            </div>
                        `;
                    }
                }, 300);
            });
        });
    }
}