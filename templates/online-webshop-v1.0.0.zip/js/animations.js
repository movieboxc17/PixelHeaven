// Intersection Observer for animating elements when they come into view
const animateOnScroll = () => {
    const elements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    elements.forEach(element => {
        observer.observe(element);
    });
};

// Fade in animation for hero section
const animateHero = () => {
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        setTimeout(() => {
            heroContent.style.opacity = '1';
            heroContent.style.transform = 'translateY(0)';
        }, 300);
    }
};

// Product card hover animation
const animateProductCards = () => {
    const productCards = document.querySelectorAll('.product-card');
    
    productCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.querySelector('.product-actions').style.opacity = '1';
            card.querySelector('.product-actions').style.transform = 'translateX(0)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.querySelector('.product-actions').style.opacity = '0';
            card.querySelector('.product-actions').style.transform = 'translateX(60px)';
        });
    });
};

// Add a smooth scroll effect to product categories section
const smoothScrollCategories = () => {
    const categoryLinks = document.querySelectorAll('.category-link');
    
    categoryLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                window.scrollTo({
                    top: targetSection.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
};

// Animate the filter dropdown in category pages
const animateFilters = () => {
    const filterToggles = document.querySelectorAll('.filter-toggle');
    
    filterToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            const filterContent = toggle.nextElementSibling;
            const icon = toggle.querySelector('i');
            
            if (filterContent.style.maxHeight) {
                filterContent.style.maxHeight = null;
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            } else {
                filterContent.style.maxHeight = filterContent.scrollHeight + 'px';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            }
        });
    });
};

// Add a parallax effect to the hero background image
const parallaxEffect = () => {
    const heroSection = document.querySelector('.hero');
    
    if (heroSection) {
        window.addEventListener('scroll', () => {
            const scrollPosition = window.pageYOffset;
            heroSection.style.backgroundPositionY = scrollPosition * 0.5 + 'px';
        });
    }
};

// Add a counter animation for statistics
const animateCounters = () => {
    const counters = document.querySelectorAll('.counter-value');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000; // Animation duration in milliseconds
        const step = target / (duration / 16); // 60fps -> ~16ms per frame
        
        let count = 0;
        const updateCounter = () => {
            count += step;
            
            if (count < target) {
                counter.textContent = Math.floor(count);
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };
        
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                updateCounter();
                observer.unobserve(counter);
            }
        });
        
        observer.observe(counter);
    });
};

// Add a fade-in animation to product images when they load
const fadeInProductImages = () => {
    const productImages = document.querySelectorAll('.product-image img');
    
    productImages.forEach(img => {
        img.style.opacity = '0';
        
        img.onload = () => {
            img.style.transition = 'opacity 0.5s ease';
            img.style.opacity = '1';
        };
        
        // If image is already loaded
        if (img.complete) {
            img.style.opacity = '1';
        }
    });
};

// Add sticky header on scroll
const stickyHeader = () => {
    const header = document.querySelector('header');
    const headerHeight = header.offsetHeight;
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > headerHeight) {
            header.classList.add('sticky');
        } else {
            header.classList.remove('sticky');
        }
    });
};

// Add back to top button functionality
const backToTop = () => {
    const backToTopBtn = document.createElement('button');
    backToTopBtn.className = 'back-to-top';
    backToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    document.body.appendChild(backToTopBtn);
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            backToTopBtn.classList.add('show');
        } else {
            backToTopBtn.classList.remove('show');
        }
    });
    
    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
};

// Initialize animations
document.addEventListener('DOMContentLoaded', () => {
    // Initialize all animations
    animateOnScroll();
    animateHero();
    setTimeout(animateProductCards, 1500); // Wait for products to load
    smoothScrollCategories();
    animateFilters();
    parallaxEffect();
    animateCounters();
    fadeInProductImages();
    stickyHeader();
    backToTop();
    
    // Initialize cart page functions if on cart page
    if (document.querySelector('.cart-container')) {
        initializeCartPage();
    }
});